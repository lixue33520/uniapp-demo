<template>
	<view>
		<view style="width: 100%; border-bottom: 0 none; position: fixed; z-index: 2">
		    <view style="background: #ffffff; position: relative">
		        <view class="h-tab vp-flex">
		            <view :class="'h-tab-item vp-flex_1 ' + (filt == '' ? 'on' : '')" data-filt=""
		                @tap="onFilterChange">全部</view>
		            <view :class="'h-tab-item vp-flex_1 ' + (filt == 1 ? 'on' : '')" data-filt="1"
		                @tap="onFilterChange">待支付</view>
		            <view :class="'h-tab-item vp-flex_1 ' + (filt == 2 ? 'on' : '')" data-filt="2"
		                @tap="onFilterChange">待服务</view>
		            <view :class="'h-tab-item vp-flex_1 ' + (filt == 3 ? 'on' : '')" data-filt="3"
		                @tap="onFilterChange">已完成</view>
		            <view :class="'h-tab-item vp-flex_1 ' + (filt == 4 ? 'on' : '')" data-filt="4"
		                @tap="onFilterChange">已取消</view>
		        </view>
		    </view>
		</view>
		<view style="height: 100rpx"></view>
		<block v-if="list != null">
			<view v-if="list != null && list.length == 0" style="padding: 40rpx 40rpx 40rpx 40rpx; text-align: center">
				<image src="/static/resource/images/empty.png" mode="widthFix" style="width: 200rpx" />
				<view class="f5">没有相关内容~</view>
			</view>
			<view v-else class="od-list">
				<block v-for="(item, index) in list" :key="index">
					<view class="od-item" @tap="toOrder" :data-id="item.out_trade_no">
						<view class="weui-cell weui-cell_access">
							<view class="weui-cell__hd">
								<view>
									<image :src="item.service_logo_image_url" mode="widthFix" class="od-logo"
										style="width: 100rpx; height: 100rpx; margin-right: 20rpx" />
								</view>
							</view>
							<view class="weui-cell__bd">
								<view>
									<text style="font-weight: bold">{{ item.service_name }}</text>
								</view>
								<view class="od-info">
									<block v-if="item.service_stype <= 20">
										<view>
											<text>{{ item.hospital_name }}（{{ item.area_name }}）</text>
										</view>
										<view>
											预约时间：
											<formater :timestamp="item.starttime" format="MM-dd hh:mm"></formater>
										</view>
										<view>
											就诊人员：
											<text>{{ item.client_name }}</text>
										</view>
									</block>
									<block v-if="item.service_stype > 20 && item.service_stype < 100">
										<view>
											<text>{{ item.hospital_name }}（{{ item.area_name }}）</text>
										</view>
										<view>
											处理时间：
											<formater :timestamp="item.starttime" format="MM-dd hh:mm"></formater>
										</view>
									</block>
									<block v-if="item.service_stype > 100">
										<view>
											服务时间：
											<formater :timestamp="item.starttime" format="MM-dd hh:mm"></formater>
										</view>
										<view>
											服务对象：
											<text>{{ item.client_name }}</text>
										</view>
										<!-- <view>服务地址：<text>{{item.address.address}}</text> </view> -->
									</block>
								</view>
							</view>
							<view class="weui-cell__ft">
								<!-- 待付款 -->
								<block v-if="item.trade_state == '待支付'">
									<view style="color: #ffa200"><text>待支付</text></view>
									<view style="color: #ffa200">
										<counter style="font-size: 24rpx" :second="item._exp_time"
											@counterOver="onCounterOver" />
									</view>
								</block>
								<!-- 进行中 -->
								<block v-if="item.trade_state == '待服务'">
									<view style="color: #1da6fd"><text>待服务</text></view>
								</block>
								<!-- 已完成 -->
								<block v-if="item.trade_state == '已完成'">
									<view style="color: #21c521"><text>已完成</text></view>
								</block>
								<!-- 已取消 -->
								<block v-if="item.trade_state == '已取消'">
									<view style="color: #999999"><text>已取消</text></view>
								</block>
							</view>
						</view>
					</view>
				</block>
			</view>
		</block>
	</view>
</template>

<script setup>
	import {
		ref,
		reactive,
		toRaw
	} from 'vue'
	import {
		onShow
	} from '@dcloudio/uni-app'

	const app = getApp()
	// 记录当前的tab
	const filt = ref('')
	// 订单列表数据
	const list = ref(null)

	onShow(() => {
		filt.value = app.globalData.orders_filt
		loadList()
	})
	// 订单状态筛选
	function onFilterChange(e) {
		const { filt: curFilt } = e.currentTarget.dataset
		if (curFilt === filt.value) return
		filt.value = curFilt
		loadList()
	}
	// 订单列表加载
	function loadList() {
		// 这里使用假数据，未测试真实接口
		mockData()
		return
		// 调用订单列表
		app.globalData.utils.request({
			url: '/order/list',
			method: 'GET',
			data: {
				state: filt.value
			},
			header: {
				token: uni.getStorageSync('token')
			},
			success: res => {
				list.value = res.data
			},
			fail: res => {
				uni.showToast({
					title: res.msg,
					icon: 'none'
				})
			}
		})
	}
	// 跳转订单详情页
	function toOrder(e) {
		uni.navigateTo({
			url: `../order/order?oid=${e.currentTarget.dataset.id}`
		})
	}
	// 倒计时结束后的回调
	function onCounterOve() {
		loadList()
	}

	function mockData() {
		list.value = [
			{
				"out_trade_no": "O-TNQMN00156",
				"demand": "",
				"hospital_id": 5,
				"hospital_name": "武汉中心医院",
				"price": "0.5",
				"receiveAddress": "北京",
				"service_code": "pz3",
				"service_id": 4,
				"service_name": "就医陪诊（尊享）",
				"service_stype": "15",
				"starttime": 1703606400000,
				"tel": "23",
				"order_start_time": 1703646073614,
				"transaction_id": "",
				"trade_state": "已取消",
				"time_end": 0,
				"uid": "19",
				"code_url": "weixin://wxpay/bizpayurl?pr=xnsLbB4zz",
				"other": "",
				"service_state": "0",
				"paidPrice": "0",
				"area_name": "中部地区",
				"service_logo_image_url": "http://159.75.169.224/uploads/20231105/90ded71dd1868829b08dae540412c039.jpeg",
				"client_name": "张三",
			},
			{
				"out_trade_no": "O-cDcHE00171",
				"demand": "",
				"hospital_id": 5,
				"hospital_name": "武汉中心医院",
				"price": "0.5",
				"receiveAddress": "北京",
				"service_code": "pz3",
				"service_id": 4,
				"service_name": "就医陪诊（尊享）",
				"service_stype": "15",
				"starttime": 1703606400000,
				"tel": "23",
				"order_start_time": 1703645340979,
				"transaction_id": "",
				"trade_state": "已取消",
				"time_end": 0,
				"uid": "19",
				"code_url": "weixin://wxpay/bizpayurl?pr=rwcb7Mozz",
				"other": "",
				"service_state": "0",
				"paidPrice": "0",
				"area_name": "中部地区",
				"service_logo_image_url": "http://159.75.169.224/uploads/20231105/90ded71dd1868829b08dae540412c039.jpeg",
				"client_name": "张三"
			},
			{
				"out_trade_no": "O-WDDcJ00187",
				"demand": "",
				"hospital_id": 5,
				"hospital_name": "武汉中心医院",
				"price": "0.5",
				"receiveAddress": "北京",
				"service_code": "pz3",
				"service_id": 4,
				"service_name": "就医陪诊（尊享）",
				"service_stype": "15",
				"starttime": 1703692800000,
				"tel": "23",
				"order_start_time": 1703750271096,
				"transaction_id": "",
				"trade_state": "已取消",
				"time_end": 0,
				"uid": "19",
				"code_url": "weixin://wxpay/bizpayurl?pr=GtdjpxIzz",
				"other": "",
				"service_state": "0",
				"paidPrice": "0",
				"area_name": "中部地区",
				"service_logo_image_url": "http://159.75.169.224/uploads/20231105/90ded71dd1868829b08dae540412c039.jpeg",
				"client_name": "张三"
			},
			{
				"out_trade_no": "O-TFmCG00121",
				"address": {
					"userName": "张三",
					"cityName": "广州市",
					"countyName": "海珠区",
					"detailInfo": "新港中路397号"
				},
				"demand": "",
				"hospital_id": 5,
				"hospital_name": "武汉中心医院",
				"price": "0.5",
				"receiveAddress": "",
				"service_code": "dp",
				"service_id": 1,
				"service_name": "代跑取药",
				"service_stype": "40",
				"starttime": 1703692800000,
				"tel": "23",
				"order_start_time": 1703750320908,
				"transaction_id": "",
				"trade_state": "已取消",
				"time_end": 0,
				"uid": "19",
				"code_url": "weixin://wxpay/bizpayurl?pr=J2RG2Jrzz",
				"other": "",
				"service_state": "0",
				"paidPrice": "0",
				"area_name": "中部地区",
				"service_logo_image_url": "http://159.75.169.224/uploads/20231105/108dd2cc5c333cffcb2911e1b159bddf.png"
			},
			{
				"out_trade_no": "O-TNQMN00156",
				"demand": "",
				"hospital_id": 5,
				"hospital_name": "武汉中心医院",
				"price": "0.5",
				"receiveAddress": "北京",
				"service_code": "pz3",
				"service_id": 4,
				"service_name": "就医陪诊（尊享）",
				"service_stype": "15",
				"starttime": 1703606400000,
				"tel": "23",
				"order_start_time": 1703646073614,
				"transaction_id": "",
				"trade_state": "已取消",
				"time_end": 0,
				"uid": "19",
				"code_url": "weixin://wxpay/bizpayurl?pr=xnsLbB4zz",
				"other": "",
				"service_state": "0",
				"paidPrice": "0",
				"area_name": "中部地区",
				"service_logo_image_url": "http://159.75.169.224/uploads/20231105/90ded71dd1868829b08dae540412c039.jpeg",
				"client_name": "张三",
			},
		]
	}
</script>

<style>
	@import './index.css'
</style>