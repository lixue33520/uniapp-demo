<template>
	<view>
		<uni-popup ref="popup" type="center" :is-mask-click="false" background-color="#fff">
			<view class="popup-content">
				<view class="group">
					<input class="uni-input" type="tel" v-model="validMobile.phone" placeholder="手机号" />
				</view>
				<view class="group">
					<input class="uni-input" v-model="validMobile.validCode" placeholder="验证码" />
					<text class="valid-text" @click="countdownChange">{{countdown.validText}}</text>
				</view>
			</view>
			<view class="btns">
				<view class="cancal" @click="cancal">取消</view>
				<view class="ok" @click="ok">确定</view>
			</view>
		</uni-popup>
	</view>
</template>

<script setup>
	import { ref, reactive, defineExpose, defineEmits } from 'vue'
	
	defineExpose({ open })
	const emit = defineEmits(['submitForm'])
	const app = getApp()
	const popup = ref(null)
	// 手机验证
	const validMobile = reactive({
		phone: '',
		validCode: ''
	})
	const countdown = reactive({
		validText: '获取验证码',
		time: 60
	})
	function open() {
		popup.value.open('center')
	}
	function cancal() {
		// 关闭弹窗
		popup.value.close()
	}
	function ok() {
		// 校验手机号和验证码
		if (!validMobile.phone || !validMobile.validCode) {
			return uni.showToast({
				title: '请检查填写数据',
				icon: 'none',
				duration: 1000
			})
		}
		
		// 验证短信
		app.globalData.utils.request({
			url: '/user/authentication',
			method: 'POST',
			data: {
				tel: validMobile.phone,
				code: validMobile.validCode
			},
			success: res => {
				// 将TOKEN缓存
				uni.setStorageSync('token', res.data.token)
				// 下单的方法
				emit('submitForm')
			},
			fail: res => {
				uni.showToast({
					title: res.msg,
					icon: 'none',
					duration: 1000
				})
			}
		})
	}
	let flag = false
	function countdownChange() {
		// 判断手机号是否存在
		if (!validMobile.phone) {
			return uni.showToast({
				title: '请输入手机号',
				icon: 'none',
				duration: 1000
			})
		}
		if (flag) return
		const time = setInterval(() => {
			if (countdown.time <= 0) {
				countdown.validText = '获取验证码'
				countdown.time = 60
				flag = false
				clearInterval(time)
			} else {
				countdown.time -= 1
				countdown.validText = `剩余${countdown.time}s`
			}
		}, 1000)
		flag = true
		// 发送验证码
		app.globalData.utils.request({
			url: '/get/code',
			method: 'POST',
			data: {
				tel: validMobile.phone
			},
			success: res => {
				uni.showToast({
					title: '验证码发送成功，请尽快验证！',
					icon: 'none',
					duration: 1000
				})
			},
			fail: err => {
				uni.showToast({
					title: err.msg,
					icon: 'none',
					duration: 1000
				})
			}
		})
	}
	
</script>

<style>

</style>
