<template>
	<view>
		<navbar />
		<view style="margin-top: 130rpx">
			search-custom
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
